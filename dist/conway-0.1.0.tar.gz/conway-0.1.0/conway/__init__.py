__version__ = '0.1.0'
__author__ = "Diogo André"

from .board import *